
SMODS.Back {
    key = 'atomic_deck',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            ante_value0 = 7
        },
        vouchers = { "v_bulgcrowd" },
    },
    loc_txt = {
        name = 'Atomic Deck',
        text = {
            [1] = 'The insanity of the century.'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.setting_blind then
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            local mod = 7
            G.E_MANAGER:add_event(Event({
                func = function()
                    ease_ante(mod)
                    G.GAME.round_resets.blind_ante = G.GAME.round_resets.blind_ante + mod
                    return true
                end,
            }))
        end
    end,
    
}