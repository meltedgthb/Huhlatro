
SMODS.Back {
    key = 'atomic_deck',
    pos = { x = 0, y = 0 },
    config = {
    },
    loc_txt = {
        name = 'Atomic Deck',
        text = {
            [1] = 'All Chips and Mult are multiplied. BY A LOT.',
            [2] = 'In fact, this deck is so overpowered,',
            [3] = 'I recommend you don\'t use it.'
        },
    },
    unlocked = false,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.setting_blind then
            G.GAME.win_ante = 1
            G.GAME.starting_params.hands = 2763
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound('timpani')
                    local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_([huhlatro]_supabuff)' })
                    if new_joker then
                        new_joker:set_edition("e_negative", true)
                        new_joker:add_sticker('eternal', true)
                    end
                    return true
                end
            }))
            G.GAME.starting_params.hands = G.GAME.starting_params.hands + 2763
        end
    end,
    
}