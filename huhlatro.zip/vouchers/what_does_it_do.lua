
SMODS.Voucher {
    key = 'what_does_it_do',
    pos = { x = 0, y = 0 },
    config = { 
        extra = {
            dollars0 = 2.727272727272727e+21
        } 
    },
    loc_txt = {
        name = 'What Does It Do?',
        text = {
            [1] = 'BULGOE?? I THOUGHT YOU WERE A JOKER, NOT A VOUCHER!'
        },
        unlock = {
            [1] = ''
        }
    },
    cost = 27,
    unlocked = false,
    discovered = false,
    no_collection = false,
    can_repeat_soul = false,
    requires = {'v_bulgcrowd'},
    atlas = 'CustomVouchers',
    redeem = function(self, card)
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    G.GAME.round_resets.reroll_cost = G.GAME.round_resets.reroll_cost - 27
                    G.GAME.current_round.reroll_cost = math.max(0,
                    G.GAME.current_round.reroll_cost - 27)
                    return true
                end
            }))
            ,
            extra = {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = 2.727272727272727e+21
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value, true)
                    card_eval_status_text(card, 'extra', nil, nil, nil, {message = "Set to $"..tostring(2.727272727272727e+21), colour = G.C.MONEY})
                    return true
                end,
                colour = G.C.MONEY
            }
        }
    end
}