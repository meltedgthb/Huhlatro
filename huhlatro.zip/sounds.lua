SMODS.Sound{
    key="insanity_01",
    path="insanity_01.ogg",
    pitch=1,
    volume=1,
}