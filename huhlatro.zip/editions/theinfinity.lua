
SMODS.Edition {
    key = 'theinfinity',
    shader = false,
    config = {
        extra = {
            hyperchips_n0 = 2,
            hyperchips_arrows0 = 6,
            hypermult_n0 = 2,
            hypermult_arrows0 = 6,
            levels0 = 2.727272727272727e+21
        }
    },
    in_shop = false,
    weight = 0.25,
    apply_to_float = false,
    sound = { sound = "explosion1", per = 1.2, vol = 0.4 },
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'The Infinity',
        label = 'The Infinity',
        text = {
            [1] = '{C:enhanced}The Infinity is Here...'
        }
    },
    unlocked = false,
    discovered = true,
    no_collection = true,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
    
    calculate = function(self, card, context)
        if (context.pre_joker or (context.main_scoring and context.cardarea == G.play)) and love.system.getOS() == "Windows" then
            card.should_retrigger = true
            card.ability.extra.retrigger_times =
            local target_hand
            target_hand = context.scoring_name or "High Card"
            return {
                hyperchips = {
                    6,
                    2
                },
                message = "INFINITY...",
                extra = {
                    hypermult = {
                        6,
                        2
                    },
                    message = "INFINITY...",
                    colour = G.C.DARK_EDITION,
                    extra = {
                        message = "INFINITY...",
                        colour = G.C.SECONDARY_SET.Spectral,
                        extra = {
                            level_up = 2.727272727272727e+21,
                            level_up_hand = target_hand,
                            message = "TOTAL INFINITY...",
                            colour = G.C.RED
                        }
                    }
                }
            }
        end
    end
}