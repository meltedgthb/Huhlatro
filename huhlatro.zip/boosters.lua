
SMODS.Booster {
    key = 'huh_pack',
    loc_txt = {
        name = "Huh Pack",
        text = {
            [1] = 'Huhlatro\'s stuff'
        },
        group_name = "huhlatro_boosters"
    },
    config = { extra = 5, choose = 3 },
    cost = 1,
    weight = 0.05,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    kind = 'Near-Impossible',
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            set = "Joker",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("6e2121"))
        ease_background_colour({ new_colour = HEX('6e2121'), special_colour = HEX("6e2121"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
        end,
    }
    