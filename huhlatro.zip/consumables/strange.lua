
SMODS.Consumable {
    key = 'strange',
    set = 'Planet',
    pos = { x = 0, y = 0 },
    loc_txt = {
        name = 'Strange...',
        text = {
            [1] = 'I could have sworn this galactic object was identified...'
        }
    },
    cost = 3,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        win_game()
        G.GAME.won = true
        return {
            message = "You Win! (From M31)"
        }
    end,
    can_use = function(self, card)
        return true
    end
}