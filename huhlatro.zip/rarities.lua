SMODS.Rarity {
    key = "awesomesauceome",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.002,
    badge_colour = HEX('2d5e5e'),
    loc_txt = {
        name = "awesomesauceome"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "bester",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.002,
    badge_colour = HEX('327e40'),
    loc_txt = {
        name = "bester"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}