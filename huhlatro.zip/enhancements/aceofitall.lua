
SMODS.Enhancement {
    key = 'aceofitall',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            hyperchips_n0 = 2,
            hyperchips_arrows0 = 3
        }
    },
    loc_txt = {
        name = 'Ace Of It All',
        text = {
            [1] = 'im in the thick of it everybody knows'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = true,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 0.5,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return {
                hyperchips = {
                    3,
                    2
                }
            }
        end
    end
}