
SMODS.Joker{ --Gar #2
    key = "gar2",
    config = {
        extra = {
            hypermult_n0 = 2763,
            hypermult_arrows0 = 5
        }
    },
    loc_txt = {
        ['name'] = 'Gar #2',
        ['text'] = {
            [1] = '{C:red}To Mars!{} ^^^^^2763 {C:red}Mult!{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 2763,
    rarity = "huhlatro_bester",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    dependencies = {"verybalanced"},
    pools = { ["huhlatro_huhlatro_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'buf' and args.source ~= 'jud' 
            or args.source == 'sho' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    set_ability = function(self, card, initial)
        card:set_edition("e_negative", true)
    end,
    
    calculate = function(self, card, context)
        if context.after and context.cardarea == G.jokers  then
        end
        if context.cardarea == G.jokers and context.joker_main  then
        end
        if context.individual and context.cardarea == G.play  then
            if love.system.getOS() == "Windows" then
                return {
                    hypermult = {
                        5,
                        2763
                    },
                    message = "no"
                }
            end
        end
    end
}