
SMODS.Joker{ --I Remember Yesterday...
    key = "irememberyesterday",
    config = {
        extra = {
            ante_value0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'I Remember Yesterday...',
        ['text'] = {
            [1] = 'When we played all day in the snow',
            [2] = 'and did all of our shenanigans...',
            [3] = 'But yesterday was a while ago now.',
            [4] = 'When will we grow young again?'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = "huhlatro_yesterday",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["huhlatro_huhlatro_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'jud' 
            or args.source == 'sho' or args.source == 'buf' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.after and context.cardarea == G.jokers  then
            return {
                
                func = function()
                    
                    local mod = 1 - G.GAME.round_resets.ante
                    ease_ante(mod)
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            G.GAME.round_resets.blind_ante = 1
                            return true
                        end,
                    }))
                    return true
                end,
                message = "Flashback..."
            }
        end
    end
}