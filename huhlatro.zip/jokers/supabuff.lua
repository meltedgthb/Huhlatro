
SMODS.Joker{ --supabuff
    key = "supabuff",
    config = {
        extra = {
            JokerSlotsNumber = 0,
            dollars0 = 2763
        }
    },
    loc_txt = {
        ['name'] = 'supabuff',
        ['text'] = {
            [1] = 'insane ahh joker'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7.777777777777778e+21,
    rarity = "huhlatro_bester",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    dependencies = {"Cryptid","cryptposting"},
    pools = { ["huhlatro_huhlatro_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.JokerSlotsNumber}}
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
        card:add_sticker('rental', true)
        card:set_edition("e_negative", true)
    end,
    
    calculate = function(self, card, context)
        if context.after and context.cardarea == G.jokers  then
            win_game()
            G.GAME.won = true
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars * 2763
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "MONEY! $$$$$", colour = G.C.MONEY})
                    return true
                end,
                extra = {
                    message = "WON!!!",
                    colour = G.C.ORANGE
                }
            }
        end
    end
}

local check_for_buy_space_ref = G.FUNCS.check_for_buy_space
G.FUNCS.check_for_buy_space = function(card)
    if card.config.center.key == "j_huhlatro_supabuff" then -- ignore slot limit when bought
        return true
    end
    return check_for_buy_space_ref(card)
end

local can_select_card_ref = G.FUNCS.can_select_card
G.FUNCS.can_select_card = function(e)
    	if e.config.ref_table.config.center.key == "j_huhlatro_supabuff" then
        		e.config.colour = G.C.GREEN
        		e.config.button = "use_card"
    	else
        		can_select_card_ref(e)
    	end
end