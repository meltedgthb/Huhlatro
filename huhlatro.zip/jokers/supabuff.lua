
SMODS.Joker{ --supabuff
    key = "supabuff",
    config = {
        extra = {
            JokerSlotsNumber = 0,
            play_size0 = 27632763276327,
            discard_size0 = 27632763276327,
            hand_size0 = 2763,
            blind_size0 = 0.00001,
            ante_value0 = 8,
            dollars0 = 2763
        }
    },
    loc_txt = {
        ['name'] = 'supabuff',
        ['text'] = {
            [1] = 'insane ahh joker'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7.777777777777778e+21,
    rarity = "huhlatro_bester",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = false,
    discovered = true,
    atlas = 'CustomJokers',
    dependencies = {"Cryptid","Cryptposting","Mayhem"},
    pools = { ["huhlatro_huhlatro_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.JokerSlotsNumber}}
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
        card:add_sticker('rental', true)
        card:set_edition("e_negative", true)
    end,
    
    calculate = function(self, card, context)
        if context.after and context.cardarea == G.jokers  then
            G.E_MANAGER:add_event(Event({
                blocking = false,
                func = function()
                    if G.STATE == G.STATES.SELECTING_HAND then
                        G.GAME.chips = G.GAME.blind.chips
                        G.STATE = G.STATES.HAND_PLAYED
                        G.STATE_COMPLETE = true
                        end_round()
                        return true
                    end
                end
            }))
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "INSANE", colour = G.C.BLUE})
                    
                    SMODS.change_play_limit(27632763276327)
                    return true
                end,
                extra = {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "INSANER", colour = G.C.BLUE})
                        
                        SMODS.change_discard_limit(27632763276327)
                        return true
                    end,
                    colour = G.C.WHITE,
                    extra = {
                        
                        func = function()
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Y", colour = G.C.BLUE})
                            
                            G.hand:change_size(2763)
                            return true
                        end,
                        colour = G.C.WHITE,
                        extra = {
                            func = function()
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.JokerSlotsNumber).." Joker Slot", colour = G.C.DARK_EDITION})
                                G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.JokerSlotsNumber
                                return true
                            end,
                            colour = G.C.DARK_EDITION,
                            extra = {
                                func = function()
                                    
                                    for i = 1, 12 do
                                        G.E_MANAGER:add_event(Event({
                                            trigger = 'after',
                                            delay = 0.4,
                                            func = function()
                                                if G.consumeables.config.card_limit > #G.consumeables.cards + G.GAME.consumeable_buffer then
                                                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                                                end
                                                
                                                play_sound('timpani')
                                                SMODS.add_card({ set = 'Planet', edition = 'e_negative', key = 'c_planet_x'})                            
                                                card:juice_up(0.3, 0.5)
                                                return true
                                            end
                                        }))
                                    end
                                    delay(0.6)
                                    
                                    if created_consumable then
                                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "INSANEEEE", colour = G.C.SECONDARY_SET.Planet})
                                    end
                                    return true
                                end,
                                colour = G.C.SECONDARY_SET.Planet,
                                extra = {
                                    func = function()
                                        local available_jokers = {}
                                        for i, joker in ipairs(G.jokers.cards) do
                                            table.insert(available_jokers, joker)
                                        end
                                        local target_joker = #available_jokers > 0 and pseudorandom_element(available_jokers, pseudoseed('copy_joker')) or nil
                                        
                                        if target_joker then
                                            G.E_MANAGER:add_event(Event({
                                                func = function()
                                                    local copied_joker = copy_card(target_joker, nil, nil, nil, target_joker.edition and target_joker.edition.negative)
                                                    copied_joker:set_edition("e_negative", true)
                                                    copied_joker:add_sticker('eternal', true)
                                                    copied_joker:add_to_deck()
                                                    G.jokers:emplace(copied_joker)
                                                    return true
                                                end
                                            }))
                                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "COPIED", colour = G.C.GREEN})
                                        end
                                        return true
                                    end,
                                    colour = G.C.GREEN,
                                    extra = {
                                        func = function()
                                            
                                            local created_joker = false
                                            if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                                                created_joker = true
                                                G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                                                G.E_MANAGER:add_event(Event({
                                                    func = function()
                                                        local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_([huhlatro]_expandedmore)' })
                                                        if joker_card then
                                                            joker_card:set_edition("e_negative", true)
                                                            
                                                        end
                                                        G.GAME.joker_buffer = 0
                                                        return true
                                                    end
                                                }))
                                            end
                                            if created_joker then
                                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "BOOM!", colour = G.C.BLUE})
                                            end
                                            return true
                                        end,
                                        colour = G.C.BLUE,
                                        extra = {
                                            func = function()
                                                
                                                local created_joker = false
                                                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                                                    created_joker = true
                                                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                                                    G.E_MANAGER:add_event(Event({
                                                        func = function()
                                                            local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_([cryptposting]_all)' })
                                                            if joker_card then
                                                                joker_card:set_edition("e_negative", true)
                                                                joker_card:add_sticker('eternal', true)
                                                            end
                                                            G.GAME.joker_buffer = 0
                                                            return true
                                                        end
                                                    }))
                                                end
                                                if created_joker then
                                                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "BAM!", colour = G.C.BLUE})
                                                end
                                                return true
                                            end,
                                            colour = G.C.BLUE,
                                            extra = {
                                                
                                                func = function()
                                                    if G.GAME.blind.in_blind then
                                                        
                                                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "INSANEERER", colour = G.C.GREEN})
                                                        G.GAME.blind.chips = G.GAME.blind.chips * 0.00001
                                                        G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                                                        G.HUD_blind:recalculate()
                                                        return true
                                                    end
                                                end,
                                                colour = G.C.GREEN,
                                                extra = {
                                                    
                                                    func = function()
                                                        
                                                        local mod = 8 - G.GAME.round_resets.ante
                                                        ease_ante(mod)
                                                        G.E_MANAGER:add_event(Event({
                                                            func = function()
                                                                G.GAME.round_resets.blind_ante = 8
                                                                return true
                                                            end,
                                                        }))
                                                        return true
                                                    end,
                                                    message = "OMGGGG",
                                                    colour = G.C.YELLOW,
                                                    extra = {
                                                        
                                                        func = function()
                                                            
                                                            local current_dollars = G.GAME.dollars
                                                            local target_dollars = G.GAME.dollars * 2763
                                                            local dollar_value = target_dollars - current_dollars
                                                            ease_dollars(dollar_value)
                                                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "MONEY! $$$$$", colour = G.C.MONEY})
                                                            return true
                                                        end,
                                                        colour = G.C.MONEY,
                                                        extra = {
                                                            swap = true,
                                                            message = "SWAPPED!",
                                                            colour = G.C.CHIPS,
                                                            extra = {
                                                                message = "WON!!!",
                                                                colour = G.C.ORANGE
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        end
    end
}

local check_for_buy_space_ref = G.FUNCS.check_for_buy_space
G.FUNCS.check_for_buy_space = function(card)
    if card.config.center.key == "j_huhlatro_supabuff" then -- ignore slot limit when bought
        return true
    end
    return check_for_buy_space_ref(card)
end

local can_select_card_ref = G.FUNCS.can_select_card
G.FUNCS.can_select_card = function(e)
    	if e.config.ref_table.config.center.key == "j_huhlatro_supabuff" then
        		e.config.colour = G.C.GREEN
        		e.config.button = "use_card"
    	else
        		can_select_card_ref(e)
    	end
end