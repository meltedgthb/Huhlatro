
SMODS.Joker{ --expanded more
    key = "expandedmore",
    config = {
        extra = {
            hypermult_n0 = 2763,
            hypermult_arrows0 = 2.7632763276327634e+216,
            hyperchips_n0 = 2763,
            hyperchips_arrows0 = 2.7632763276327634e+216
        }
    },
    loc_txt = {
        ['name'] = 'expanded more',
        ['text'] = {
            [1] = '{C:blue}OMG THIS GIVES 2.763e+216 {C:red} Mult and {C:blue} Chips!!{C:spades} T{C:hearts}H{C:clubs}I{C:diamonds}S {C:default}is {C:red}I{C:blue}N{C:green}S{C:purple}A{C:attention}N{C:inactive}E{C:red}!{C:blue}!{C:green}!'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1.234567890123457e+21,
    rarity = "huhlatro_awesomesauceome",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = false,
    discovered = true,
    atlas = 'CustomJokers',
    dependencies = {"Cryptid","Cryptposting"},
    pools = { ["huhlatro_huhlatro_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rif' and args.source ~= 'sou' 
            or args.source == 'sho' or args.source == 'rta' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        local info_queue_0 = G.P_CENTERS["j_joker"]
        if info_queue_0 then
            info_queue[#info_queue + 1] = info_queue_0
        else
            error("JOKERFORGE: Invalid key in infoQueues. \"j_joker\" isn't a valid Object key, Did you misspell it or forgot a modprefix?")
        end
        return {vars = {}}
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
        card:set_edition("e_negative", true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if love.system.getOS() == "Windows" then
                return {
                    hypermult = {
                        2.7632763276327634e+216,
                        2763
                    },
                    message = "Watch BFDI 25",
                    extra = {
                        hyperchips = {
                            2.7632763276327634e+216,
                            2763
                        },
                        message = "YOYLECAKE!",
                        colour = G.C.DARK_EDITION
                    }
                }
            end
        end
    end
}

local check_for_buy_space_ref = G.FUNCS.check_for_buy_space
G.FUNCS.check_for_buy_space = function(card)
    if card.config.center.key == "j_huhlatro_expandedmore" then -- ignore slot limit when bought
        return true
    end
    return check_for_buy_space_ref(card)
end

local can_select_card_ref = G.FUNCS.can_select_card
G.FUNCS.can_select_card = function(e)
    	if e.config.ref_table.config.center.key == "j_huhlatro_expandedmore" then
        		e.config.colour = G.C.GREEN
        		e.config.button = "use_card"
    	else
        		can_select_card_ref(e)
    	end
end