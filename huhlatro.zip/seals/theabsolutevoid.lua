
SMODS.Seal {
    key = 'theabsolutevoid',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            xchips0 = 0,
            xmult0 = 0
        }
    },
    badge_colour = HEX('000000'),
    loc_txt = {
        name = 'The Absolute Void',
        label = 'The Absolute Void',
        text = {
            [1] = 'The Absolute Void. Makes all effects nonexistent.'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    sound = { sound = "win", per = 1, vol = 1.5 },
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return {
                x_chips = 0,
                message = "ABSOLUTE VOID",
                extra = {
                    Xmult = 0,
                    message = "ABSOLUTE VOID"
                }
            }
        end
    end
}